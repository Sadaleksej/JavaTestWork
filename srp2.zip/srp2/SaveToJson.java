package ru.geekbrains.lesson6.srp2;

import java.io.FileWriter;
import java.io.IOException;


public class SaveToJson {

    private Toy toy;

    public SaveToJson(Toy toy){this.toy = toy;}

    public void saving() {
        String fileName = "toys.json";
        try (FileWriter writer = new FileWriter(fileName, false)) {
            writer.write("{\n");
            writer.write("\"ToyId\":\""+ toy.getId() + "\",\n");
            writer.write("\"Name\":\""+toy.getName()+"\",\n");
            writer.write("\"Weight\":"+toy.getWeight()+",\n");
            writer.write("}\n");
            writer.flush();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

}
