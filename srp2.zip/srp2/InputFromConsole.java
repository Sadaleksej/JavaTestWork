package ru.geekbrains.lesson6.srp2;

import java.util.Scanner;

public class InputFromConsole {

    private Toy toy;

    private Scanner scanner = new Scanner(System.in);

    public InputFromConsole(Toy toy){this.toy = toy;};

        public void filling(){
        toy.setId(Integer.parseInt(prompt("Toy ID: ")));
        toy.setName(prompt("Toy name: "));
        toy.setWeight(Integer.parseInt(prompt("Toy weight: ")));
        
    }

    private String prompt(String message){
        System.out.println(message);
        return scanner.nextLine();
    }



}
