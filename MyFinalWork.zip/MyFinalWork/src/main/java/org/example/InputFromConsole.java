package org.example;


    import java.util.Scanner;

    public class InputFromConsole {

        private static Toy toy;

        private static Scanner scanner = new Scanner(System.in);



        public static Toy filling(){
            Toy toy = new Toy(1,"",1);
            try {
                toy.setId(Integer.parseInt(prompt("Toy ID: ")));
            } catch (NullPointerException e){};


            toy.setName(prompt("Toy name: "));
            try {
                toy.setWeight(Integer.parseInt(prompt("Toy weight: ")));
            } catch (NullPointerException e){};
return toy;

        }

        private static String prompt(String message){
            System.out.println(message);
            return scanner.nextLine();
        }



    }




