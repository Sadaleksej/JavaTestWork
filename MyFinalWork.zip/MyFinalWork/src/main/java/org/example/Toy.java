package org.example;


public class Toy implements Comparable <Toy>{

    private int id;
    private String name;
    private int weight;


    public Toy(int id_toy, String name_toy, int weight_toy) {
        this.id = id_toy;
        this.name = name_toy;
        this.weight = weight_toy;
    }


    public void setName(String name) {
        this.name = name;}

    public void setId(int id) {
        this.id = id;}

    public void setWeight(int weight) {
        this.weight = weight;}

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }
    public int getWeight() {
        return weight;
    }

    @Override
    public int compareTo(Toy other) {
        if (other == null) {
            return -1; // this < other
        }
        int delta = this.weight - other.weight;
        if (delta != 0) {
            return - delta;
        }
        return this.name.compareTo(other.name);
    }

}

