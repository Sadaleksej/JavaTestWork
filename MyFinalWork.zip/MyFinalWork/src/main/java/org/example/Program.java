package org.example;

import java.util.PriorityQueue;
import org.example.Toy;
import java.util.Random;

public class Program {


    public static void main(String[] args) {

        // Toy toy = new Toy();

        // InputFromConsole inputFromConsole = new InputFromConsole(toy);
        // inputFromConsole.filling();
        // SaveToJson saveToJson = new SaveToJson(toy);
        // saveToJson.saving();

        Toy[] toys = new Toy[20];

        int totalWeight = 0;
        //Toy[] typesOfToys = {
        //    new Toy(1,"Mouse", 2),
        //    new Toy(2,"Bear", 5),
        //    new Toy(3,"Constructor", 5),
        //    new Toy(4,"Doll", 1),
        //    new Toy(5,"Ball", 3),
        //};

        Toy[] typesOfToys = PutToy.ToyListCreation(5).toArray(new Toy[0]);

        for (Toy toy : typesOfToys) {
            totalWeight += toy.getWeight();
        }

        Random random = new Random();
        for (int i = 0; i < 20; i++) {
            int randomNumber = random.nextInt(totalWeight) + 1;
            int cumulativeWeight = 0;

            for (Toy toy : typesOfToys) {
                cumulativeWeight += toy.getWeight();
                if (randomNumber <= cumulativeWeight) {
                    toys[i] = new Toy(toy.getId(), toy.getName(), toy.getWeight());
                    break;
                }
            }
        }

        for (Toy toy : toys) {
            System.out.println("Toy: " + toy.getName() + ", Weight: " + toy.getWeight());
        }



        // Toy tom = new Toy(1,"Tom", 2);
        // Toy jerry = new Toy(2,"Jerry", 5);
        // Toy donald = new Toy(3,"Donald", 3);
        // Toy mickey = new Toy(4,"Mickey", 8);
        // Toy daffy = new Toy(5, "Daffy", 9);

        // PriorityQueue<Toy> queue = new PriorityQueue<>();

        // queue.add(tom);
        //queue.add(jerry);
        //queue.add(donald);
        //queue.add(mickey);
        //queue.add(daffy);

        //Toy currentToy = null;

        //while((currentToy = queue.poll())!= null) {
        //    System.out.println("--- Toy Weight: " + currentToy.getId() + " ---");
        //    System.out.println("--- Toy Name: " + currentToy.getName() + " ---");
        //    System.out.println("--- Toy Weight: " + currentToy.getWeight());
        //    System.out.println();
        //}

    }

}