package org.example;
import java.util.ArrayList;
import java.util.List;

import org.example.InputFromConsole;
import org.example.Toy;

public class PutToy {

    private int ammount;



    public static ArrayList<Toy> ToyListCreation(int ammount){
        ArrayList<Toy> toysList = new ArrayList<>();
        for (int i = 0; i < ammount; i++){

            InputFromConsole inputFromConsole = new InputFromConsole();
            Toy toy = inputFromConsole.filling();
            toysList.add(toy);
        }
        return toysList;
    }







}
